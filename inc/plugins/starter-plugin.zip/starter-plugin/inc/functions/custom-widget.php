<?php
/**
 * Register custom widget
 *
 *
 * @package starter
 */


function starter_register_widgets_init() {

    /**************************************************************************************
    Recent & Popular post widget
    **************************************************************************************/

    class starter_mrecent_widget extends WP_Widget{

        public function __construct(){
            $widget_details = array(
                'classname' => 'starter_mrecent_widget',
                'description' => esc_html__( 'About Widget.', 'starter' )
            );
            parent::__construct( 'starter_mrecent_widget', esc_html__( '&#9733; Recent & Popular Widget', 'starter' ), $widget_details );
        }
      
        public function widget( $args, $instance ){ 

        $popular_title = $instance['popular_title'];
        $latest_title = $instance['latest_title'];
        $postscount = $instance['posts'];
            
        // Popular posts
        $popular_post = new WP_Query(
            array(
                'posts_per_page' => $postscount,
                'post_type'      => 'post',
                'meta_key'       => 'starter_post_views_count',
                'orderby'        => 'meta_value_num',
                'post__not_in'   => get_option( 'sticky_posts' ),
            )
        );
            
        // Latest posts
       $latest_post = new WP_Query(
            array(
                'posts_per_page' => $postscount,
                'post_type'      => 'post',
                'order'          => 'DESC',
                'post__not_in'   => get_option( 'sticky_posts' ),
            )
        );

        global $post;       

        ?>

        <div class="blog-list-right">
            <div class="recent-popular-post">
                <ul class="nav nav-tabs nav-justified recent-popular-nav" id="myTab" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" id="popular-tab" data-toggle="tab" href="#popular" role="tab" aria-controls="popular" aria-selected="true"><?php echo esc_html( $popular_title ); ?></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false"><?php echo esc_html( $latest_title ); ?></a>
                  </li>
                </ul>

                <div class="tab-content recent-popular-tab" id="myTabContent">
                  <div class="tab-pane fade show active" id="popular" role="tabpanel" aria-labelledby="popular-tab">
                        <div class="recent-post">

                        <?php  //SHOW the posts
                        $i = 1;
                        if( $popular_post -> have_posts() ) :
                        while ( $popular_post -> have_posts() ): 
                        $popular_post -> the_post();                    
                        ?>                        
                            
                        <div class="media">
                          <span class="blog-count"><?php echo esc_html( $i++ ); ?></span>
    					  <?php the_post_thumbnail(); ?>
    					  <div class="media-body">
                            <span class="widget-category">
                                <?php
                                    $terms = get_the_terms( $post->ID , 'category' );
                                    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                                        foreach ( $terms as $term ) {
                                            ?>
                                
                                            <a href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a> 

                                            <?php                             
                                        }
                                    }
                                
                                ?>
                            </span>
    					    <a href="<?php the_permalink(); ?>"><?php echo starter_excerpt_char_course_title( '25' ); ?></a>
    					    <p><i class="fa fa-clock-o"></i> <?php the_time( 'M d, Y' ); ?></p>				
    					  </div>
    					</div>

                        <?php          
                        endwhile;

                        else:
                        	echo "<br>";
                       	 	esc_html_e( 'There has popular post.','starter' );                     
                        endif; 
                        wp_reset_postdata();   
                        ?>

                        </div><!-- end /.post-list -->
                  </div>
                  <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                        
                        <div class="recent-post">

                        <?php  //SHOW the posts
                        $i = 1;
                        if( $latest_post -> have_posts() ) :
                        while ( $latest_post -> have_posts() ): 
                        $latest_post -> the_post();                    
                        ?>                        
                            
                        <div class="media">
                          <span class="blog-count"><?php echo esc_html( $i++ ); ?></span>
                          <?php the_post_thumbnail(); ?>
                          <div class="media-body">
                            <span class="widget-category">
                                <?php
                                    $terms = get_the_terms( $post->ID , 'category' );
                                    if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
                                        foreach ( $terms as $term ) {
                                            ?>
                                
                                            <a href="<?php echo esc_url( get_term_link( $term ) ); ?>"><?php echo esc_html( $term->name ); ?></a> 

                                            <?php                             
                                        }
                                    }                                
                                ?>
                            </span>
                            <a href="<?php the_permalink(); ?>"><?php echo starter_excerpt_char_course_title( '25' ); ?></a>
                            <p><i class="fa fa-clock-o"></i> <?php the_time( 'M d, Y' ); ?></p>             
                          </div>
                        </div>
    						
                        <?php          
                        endwhile;

                        else:
                        	echo "<br>";
                       	 	esc_html_e( 'There has popular post.','starter' );                     
                        endif; 
                        wp_reset_postdata();   
                        ?>
                    	</div>
                    </div>                             
                </div>
            </div>
        </div>               

        <?php
        }

        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }

        public function form( $instance ){          
            
            $popular_title = esc_html__( 'Popular','starter' );
            if(isset($instance['popular_title']))
            {
                $popular_title = $instance['popular_title'];
            }
            
            $latest_title = esc_html__( 'Latest','starter' );
            if(isset($instance['latest_title']))
            {
                $latest_title = $instance['latest_title'];
            }

            $posts = 3;
            if( !empty( $instance['posts'] ) ) {
                $posts = $instance['posts'];
            } 

            ?>       

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( 'popular_title' ) ); ?>"><?php esc_html_e( 'Popular Title','starter' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( 'popular_title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'popular_title' ) ); ?>" type="text" value="<?php echo esc_attr( $popular_title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( 'latest_title' ) ); ?>"><?php esc_html_e( 'Latest Title','starter' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( 'latest_title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'latest_title' ) ); ?>" type="text" value="<?php echo esc_attr( $latest_title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( 'posts' ) ); ?>"><?php esc_html_e( 'posts','starter' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( 'posts' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'posts' ) ); ?>" type="text" value="<?php echo esc_attr( $posts ); ?>" />
            </p> 

        <?php
        }
    }
    register_widget( 'starter_mrecent_widget' );


    //**************************************************************************************
    // Custom Link Widget
    //**************************************************************************************

    class starter_footer_link_widget extends WP_Widget{        
        
        // Construct fn for id, title and description of the widget
        public function __construct()
        {
            $widget_details = array(
                'classname' => 'starter_footer_link_widget',
                'description' => esc_html__( 'Footer Link Widget.','starter' )
            );
            parent::__construct( 'starter_footer_link_widget', esc_html__( '&#9733; Footer Link Widget','starter' ) , $widget_details );
        }
      
        // Output of the widget
        public function widget( $args, $instance ) {
    		
            $title = ! empty( $instance['title'] ) ? $instance['title']: ''; 
            $grid = ! empty( $instance['grid'] ) ? $instance['grid']: ''; 
            
    		?>

    	    <div class="col-md-<?php echo esc_attr( $grid ); ?>">
    			<div class="single-link">
    				<h3><?php echo esc_html( $title ); ?></h3>	
    				<ul>
    					<?php for( $i=1; $i<=$instance["inputbox"]; $i++ ) {		            
    		            // Variable defind
    		            $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;	
    		            
    		            if( $link_text ): ?><li><a href="<?php echo esc_url( $instance["link_url$i"] )  ?>"><?php echo esc_html( $link_text )  ?></a></li><?php endif;
    		            
    		        } ?>									
    				</ul>
    			</div>	
    		</div>            
    		<?php
        }    
        
        // Update user input data
    	public function update( $new_instance, $old_instance ) {  
    	    return $new_instance;
    	}
        
        // Dashboard widget form
        public function form( $instance ) {

            $title = ! empty( $instance["title"] ) ? $instance["title"] : '' ;
            $grid = ! empty( $instance['grid'] ) ? $instance['grid']: ''; 
            $inputbox = ! empty( $instance["inputbox"] ) ? $instance["inputbox"] : '' ;

            ?>
        
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>"><b><?php esc_html_e( "Select Grid","starter" ); ?></b></label>            
                <select class="widefat" id="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>">
                  <option value="2" <?php if( $grid == 2 ): echo "selected"; endif; ?> ><?php esc_html_e( '2 Colomn Grid','starter' ); ?></option>
                  <option value="3" <?php if( $grid == 3 ): echo "selected"; endif; ?>><?php esc_html_e( '3 Colomn Grid','starter' ); ?></option>
                  <option value="4" <?php if( $grid == 4 ): echo "selected"; endif; ?> ><?php esc_html_e( '4 Colomn Grid','starter' ); ?></option>
                  <option value="6" <?php if( $grid == 6 ): echo "selected"; endif; ?> ><?php esc_html_e( '6 Colomn Grid','starter' ); ?></option>
                </select>
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many field would you want? & hit save.","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
    		for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind
                $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;
                $link_url = ! empty( $instance["link_url$i"] ) ? $instance["link_url$i"] : '' ;		

                ?>	

                <!-- Link 1 -->
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>"><?php echo esc_html( "Link text $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_text ); ?>" />
            
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>"><?php echo esc_html( "Link url $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_url ); ?>" />
                </p>
            
            <?php } ?>
           
        <?php                
        }
    }
    register_widget( 'starter_footer_link_widget' );
    

    //**************************************************************************************
    // Mega Menu Item Widget
    //**************************************************************************************

    class starter_mega_menu_item_widget extends WP_Widget{        
        
        // Construct fn for id, title and description of the widget
        public function __construct()
        {
            $widget_details = array(
                'classname' => 'starter_mega_menu_item_widget',
                'description' => esc_html__( 'Mega Menu Item Widget.','starter' )
            );
            parent::__construct( 'starter_mega_menu_item_widget', esc_html__( '&#9733; Mega Menu Item Widget','starter' ) , $widget_details );
        }
      
        // Output of the widget
        public function widget( $args, $instance ) {
    		
            $title = ! empty( $instance['title'] ) ? $instance['title']: ''; 
            $grid = ! empty( $instance['grid'] ) ? $instance['grid']: '';             
            
    		?>
    	    <div class="col-md-<?php echo esc_attr( $grid ); ?>">
    			<div class="menu-single-item">
    				<h3><?php echo esc_html( $title ); ?></h3>  
    				<?php for( $i=1; $i<=$instance["inputbox"]; $i++ ) {                        
                        $instance["new_tab$i"] = isset( $instance["new_tab$i"] ) ? 1 : false;
    		            // Variable defind                        
                        $sticker_class = isset( $instance["sticker_class$i"] ) ? $instance["sticker_class$i"] : '';
    		            $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;    		            
    		            if( $link_text ): ?><a class="<?php echo esc_attr( $sticker_class ); ?>" <?php if( $instance["new_tab$i"] ): echo 'target="_blank"'; endif; ?> href="<?php echo esc_url( $instance["link_url$i"] )  ?>"><?php echo esc_html( $link_text )  ?></a><?php endif;
    		        } ?>
    			</div>	
    		</div>            
    		<?php
        }    
        
        // Update user input data
    	public function update( $new_instance, $old_instance ) {  
    	    return $new_instance;
    	}
        
        // Dashboard widget form
        public function form( $instance ) {

            $title = ! empty( $instance["title"] ) ? $instance["title"] : '' ;
            $grid = ! empty( $instance['grid'] ) ? $instance['grid']: ''; 
            $inputbox = ! empty( $instance["inputbox"] ) ? $instance["inputbox"] : '' ;

            ?>
        
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>"><b><?php esc_html_e( "Select Grid","starter" ); ?></b></label>            
                <select class="widefat" id="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "grid" ) ); ?>">
                  <option value="2" <?php if( $grid == 2 ): echo "selected"; endif; ?> ><?php esc_html_e( '2 Colomn Grid','starter' ); ?></option>
                  <option value="3" <?php if( $grid == 3 ): echo "selected"; endif; ?>><?php esc_html_e( '3 Colomn Grid','starter' ); ?></option>
                  <option value="4" <?php if( $grid == 4 ): echo "selected"; endif; ?> ><?php esc_html_e( '4 Colomn Grid','starter' ); ?></option>
                  <option value="6" <?php if( $grid == 6 ): echo "selected"; endif; ?> ><?php esc_html_e( '6 Colomn Grid','starter' ); ?></option>
                  <option value="12" <?php if( $grid == 12 ): echo "selected"; endif; ?> ><?php esc_html_e( '12 Colomn Grid','starter' ); ?></option>
                </select>
            </p>           
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many field would you want? & hit save.","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
    		for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind
                $sticker_class = ! empty( $instance["sticker_class$i"] ) ? $instance["sticker_class$i"] : '' ;
                $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;
                $link_url = ! empty( $instance["link_url$i"] ) ? $instance["link_url$i"] : '' ;		
                $new_tab = ! empty( $instance["new_tab$i"] ) ? $instance["new_tab$i"] : '' ;	

                ?>	

                <!-- Link 1 -->
                <p>                
                    <label for="<?php echo esc_attr( $this->get_field_name( "sticker_class$i" ) ); ?>"><b><?php echo esc_html( "Sticker Class $i Ex: sticker-new, sticker-trendy ","starter" ); ?></b></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "sticker_class$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "sticker_class$i" ) ); ?>" type="text" value="<?php echo esc_attr( $sticker_class ); ?>" />
                
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>"><?php echo esc_html( "Link text $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_text ); ?>" />
            
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>"><?php echo esc_html( "Link url $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_url ); ?>" />
                
                    <input type="checkbox" id="<?php echo esc_attr( $this->get_field_name( "new_tab$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "new_tab$i" ) ); ?>" value="1" <?php checked( '1', $new_tab ); ?>>
                    <label for="<?php echo esc_attr( $this->get_field_name( "new_tab$i" ) ); ?>"> <?php esc_html_e( 'Open link in a new tab', 'starter' ); ?></label>
                </p>
            
            <?php } ?>           
        <?php                
        }
    }
    register_widget( 'starter_mega_menu_item_widget' );


    //**************************************************************************************
    // Mega Menu thumbnail Item Widget
    //**************************************************************************************

    class starter_mega_menu_thumbnail_item_widget extends WP_Widget{        
        
        // Construct fn for id, title and description of the widget
        public function __construct()
        {
            $widget_details = array(
                'classname' => 'starter_mega_menu_thumbnail_item_widget',
                'description' => esc_html__( 'Mega Menu Item Widget.','starter' )
            );
            parent::__construct( 'starter_mega_menu_thumbnail_item_widget', esc_html__( '&#9733; Mega Menu Thumbnail Item Widget','starter' ) , $widget_details );
        }
      
        // Output of the widget
        public function widget( $args, $instance ) {
    		
            $title = ! empty( $instance['title'] ) ? $instance['title']: '';                         
        
            for( $i=1; $i<=$instance["inputbox"]; $i++ ) { 
                
                $grid = ! empty( $instance["grid$i"] ) ? $instance["grid$i"]: '';
                $image_uri = ! empty( $instance["image_uri$i"] ) ? $instance["image_uri$i"]: '';
                $desc = ! empty( $instance["desc$i"] ) ? $instance["desc$i"]: ''; 
                $instance["new_tab$i"] = isset( $instance["new_tab$i"] ) ? 1 : false; ?>
                    
                <div class="col-md-<?php echo esc_attr( $grid ); ?>">

                <a class="mega-menu-thumbnail-item <?php echo esc_attr( $instance["sticker_class$i"] ); ?>" <?php if( $instance["new_tab$i"] ): echo 'target="_blank"'; endif; ?> href="<?php echo esc_url( $instance["link_url$i"] )  ?>">
                    <div class="thumbnail-item">
                        <?php if( $instance["image_uri$i"] ): ?>    
                        <div class="thumbnail-item-left">
                            <img src="<?php echo esc_url($instance["image_uri$i"]); ?>" alt="<?php the_title_attribute(); ?>">
                        </div>
                        <?php endif; ?>

                        <div class="thumbnail-item-right">
                            <?php

                            // Variable defind                        
                            $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;    		            
                            if( $link_text ): ?><h3><?php echo esc_html( $link_text ); ?></h3><?php endif;
                            if( $desc ): ?><p><?php echo esc_html( $desc )  ?></p><?php endif;
                            
                            ?>
                        </div>
                    </div>
                </a>

                </div>	
            <?php }
        } 
        
        // Update user input data
    	public function update( $new_instance, $old_instance ) {  
    	    return $new_instance;
    	}
        
        // Dashboard widget form
        public function form( $instance ) {

            $title = ! empty( $instance["title"] ) ? $instance["title"] : '' ;
            $grid = ! empty( $instance['grid'] ) ? $instance['grid']: ''; 
            $inputbox = ! empty( $instance["inputbox"] ) ? $instance["inputbox"] : '' ;

            ?>
        
                       
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many field would you want? & hit save.","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
    		for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind
                $grid = ! empty( $instance["grid$i"] ) ? $instance["grid$i"]: '';
                $image_uri = ! empty( $instance["image_uri$i"] ) ? $instance["image_uri$i"]: '';
                $sticker_class = ! empty( $instance["sticker_class$i"] ) ? $instance["sticker_class$i"] : '';
                $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '';
                $link_url = ! empty( $instance["link_url$i"] ) ? $instance["link_url$i"] : '';		
                $new_tab = ! empty( $instance["new_tab$i"] ) ? $instance["new_tab$i"] : '';	
                $desc = ! empty( $instance["desc$i"] ) ? $instance["desc$i"] : '';	

                ?>	

                <!-- Link 1 -->
                <p>

                    <p>
                        <label for="<?php echo esc_attr( $this->get_field_name( "grid$i" ) ); ?>"><b><?php esc_html_e( "Select Grid","starter" ); ?></b></label>            
                        <select class="widefat" id="<?php echo esc_attr( $this->get_field_name( "grid$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "grid$i" ) ); ?>">
                            <option value="2" <?php if( $grid == 2 ): echo "selected"; endif; ?> ><?php esc_html_e( '2 Colomn Grid','starter' ); ?></option>
                            <option value="3" <?php if( $grid == 3 ): echo "selected"; endif; ?>><?php esc_html_e( '3 Colomn Grid','starter' ); ?></option>
                            <option value="4" <?php if( $grid == 4 ): echo "selected"; endif; ?> ><?php esc_html_e( '4 Colomn Grid','starter' ); ?></option>
                            <option value="6" <?php if( $grid == 6 ): echo "selected"; endif; ?> ><?php esc_html_e( '6 Colomn Grid','starter' ); ?></option>
                            <option value="12" <?php if( $grid == 12 ): echo "selected"; endif; ?> ><?php esc_html_e( '12 Colomn Grid','starter' ); ?></option>
                        </select>
                    </p>

                    <p>
                        <label for="<?php echo esc_attr( $this->get_field_name( 'image_uri'.$i )); ?>"><?php esc_html_e( 'Background Image', 'welearner' ); ?></label>
                        <img class="<?php echo esc_attr( $this->id.$i ); ?>_img" src="<?php echo esc_url( $image_uri ); ?>" style="width: 100%;"/>
                        <input type="text" class="widefat <?php echo esc_attr( $this->id.$i ); ?>_url" name="<?php echo esc_attr( $this->get_field_name( 'image_uri'.$i )); ?>" value="<?php echo esc_attr( $image_uri ); ?>" />
                        <input type="button" id="<?php echo esc_attr( $this->id.$i ); ?>" class="button button-primary js_custom_upload_media" value="Upload Image" />
                    </p>
                    
                    <label for="<?php echo esc_attr( $this->get_field_name( "sticker_class$i" ) ); ?>"><b><?php echo esc_html( "Sticker Class $i Ex: sticker-new, sticker-trendy ","starter" ); ?></b></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "sticker_class$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "sticker_class$i" ) ); ?>" type="text" value="<?php echo esc_attr( $sticker_class ); ?>" />
                
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>"><?php echo esc_html( "Link text $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_text ); ?>" />
            
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>"><?php echo esc_html( "Link url $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_url ); ?>" />
                
                    <label for="<?php echo esc_attr( $this->get_field_name( "desc$i" ) ); ?>"><?php esc_html_e( 'Description','starter' ); ?></label>
                    <textarea class="widefat" id="<?php echo esc_attr( $this->get_field_name( "desc$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "desc$i" ) ); ?>" type="text"><?php echo wp_kses_post( $desc ); ?></textarea>

                    <input type="checkbox" id="<?php echo esc_attr( $this->get_field_name( "new_tab$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "new_tab$i" ) ); ?>" value="1" <?php checked( '1', $new_tab ); ?>>
                    <label for="<?php echo esc_attr( $this->get_field_name( "new_tab$i" ) ); ?>"> <?php esc_html_e( 'Open link in a new tab', 'starter' ); ?></label>
                </p>
            
            <?php } ?>           
        <?php                
        }
    }
    register_widget( 'starter_mega_menu_thumbnail_item_widget' );


    //**************************************************************************************
    // About me widget
    //**************************************************************************************

    class starter_about_widget extends WP_Widget{

        public function __construct() {
            $widget_details = array(
                'classname' => 'starter_about_widget',
                'description' => esc_html__( 'About Widget.', 'starter' )
            );
            parent::__construct( 'starter_about_widget', esc_html__('&#9733; About Widget','starter'), $widget_details );
        }

        public function widget( $args, $instance ) {
    		
            $title = ! empty( $instance['title'] ) ? $instance['title']: '';
            $inputbox = ! empty( $instance["inputbox"] ) ? $instance["inputbox"] : ''; 

    		?>
    		
            <div class="footer-about">                                                      
                <?php if( $instance['image_uri'] ): ?><img src="<?php echo esc_url($instance['image_uri']); ?>" alt="<?php the_title_attribute(); ?>"><?php endif; ?>
                <?php if( $instance['desc'] ): ?><p><?php echo wp_kses_post( $instance['desc'] );  ?></p><?php endif; ?>
                <ul>
                    <?php if( $instance['phone'] ): ?><li><?php echo esc_html( $instance['phone'] ); ?></li><?php endif; ?>
                    <?php if( $instance['email'] ): ?><li><?php echo esc_html( $instance['email'] ); ?></li><?php endif; ?>                                                                                     
                </ul>

                <?php if( $inputbox ): ?>
                <div class="footer-social-link">               
                    <ul>                    
                        <?php for( $i=1; $i<=$inputbox; $i++ ) {
                        
                            // Variable defind
                            $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;  

                            if( $link_text ): ?><li><a href="<?php echo esc_url( $instance["link_url$i"] )  ?>"> <i class="<?php echo esc_attr( $link_text );  ?>"></i> </a></li><?php endif;

                        } ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>

    	<?php
        }

    	public function update( $new_instance, $old_instance ) {  
    	    return $new_instance;
    	}

        public function form( $instance ) {
    			    
    		$image = '';
    		if(isset($instance['image']))
    		{
    		    $image = $instance['image'];
    		}

    		$desc = '';
    	    if( !empty( $instance['desc'] ) ) {
    	        $desc = $instance['desc'];
    	    }

    		$email = '';
    	    if( !empty( $instance['email'] ) ) {
    	        $email = $instance['email'];
    	    }

    		$phone = '';
    	    if( !empty( $instance['phone'] ) ) {
    	        $phone = $instance['phone'];
    	    }

    		$desc = '';
    	    if( !empty( $instance['desc'] ) ) {
    	        $desc = $instance['desc'];
    	    }

            // About social
            $title = ! empty( $instance['title'] ) ? $instance['title']: ''; 
            $inputbox = ! empty( $instance["inputbox"] ) ? $instance["inputbox"] : '' ;
            $image_uri = isset( $instance['image_uri'] ) ? $instance['image_uri']: ''; 

            ?>	            

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( 'image_uri' )); ?>"><?php esc_html_e( 'Background Image', 'welearner' ); ?></label>
                <img class="<?php echo esc_attr( $this->id ); ?>_img" src="<?php echo esc_url( $image_uri ); ?>" style="width: 100%;"/>
                <input type="text" class="widefat <?php echo esc_attr( $this->id ); ?>_url" name="<?php echo esc_attr( $this->get_field_name( 'image_uri' )); ?>" value="<?php echo esc_attr( $image_uri ); ?>" />
                <input type="button" id="<?php echo esc_attr( $this->id ); ?>" class="button button-primary js_custom_upload_media" value="Upload Image" />
            </p>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( 'desc' ) ); ?>"><?php esc_html_e( 'Description','starter' ); ?></label>
                <textarea class="widefat" id="<?php echo esc_attr( $this->get_field_name( 'desc' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'desc' ) ); ?>" type="text"><?php echo wp_kses_post( $desc ); ?></textarea>
            </p> 

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>"><?php esc_html_e( 'Email','starter' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'email' ) ); ?>" type="text" value="<?php echo esc_attr( $email ); ?>" />
            </p>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>"><?php esc_html_e( 'Phone','starter' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'phone' ) ); ?>" type="text" value="<?php echo esc_attr( $phone ); ?>" />
            </p>          

            <!-- About social widget -->
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many social field would you want? & hit save.","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind
                $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;
                $link_url = ! empty( $instance["link_url$i"] ) ? $instance["link_url$i"] : '' ;     

                ?>  
                <!-- Link 1 -->
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>"><?php echo esc_html( "Fontawesome 4 Icon Class $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_text ); ?>" />
            
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>"><?php echo esc_html( "Link url $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_url ); ?>" />
                </p>
            
            <?php } ?> 
        <?php
        }
    }
    register_widget( 'starter_about_widget' );


    //**************************************************************************************
    // Custom bottom link Widget
    //**************************************************************************************

    class starter_footer_bottom_link_widget extends WP_Widget{    
        
        // Construct fn for id, title and description of the widget
        public function __construct()
        {
            $widget_details = array(
                'classname' => 'starter_footer_bottom_link_widget',
                'description' => esc_html__( 'Footer Bottom Link Widget.','starter' )
            );
            parent::__construct( 'starter_footer_bottom_link_widget', esc_html__( '&#9733; Footer Bottom Link Widget','starter' ) , $widget_details );
        }
      
        // Output of the widget
        public function widget( $args, $instance ) {
            
            $title = ! empty( $instance['title'] ) ? $instance['title']: ''; 
            
            for( $i=1; $i<=$instance["inputbox"]; $i++ ) {            
                // Variable defind
                $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ; 
                if( $link_text ): ?><li><a href="<?php echo esc_url( $instance["link_url$i"] )  ?>"> <?php echo esc_html( $link_text ); ?> </a></li><?php endif;
            } 
        }    
        
        // Update user input data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Admin widget form
        public function form( $instance ) {

            $title = ! empty( $instance['title'] ) ? $instance['title']: ''; 
            $inputbox = ! empty( $instance["inputbox"] ) ? $instance["inputbox"] : '' ;

            ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many social field would you want? & hit save.","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

                // Variable defind
                $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;
                $link_url = ! empty( $instance["link_url$i"] ) ? $instance["link_url$i"] : '' ;     

                ?>  
                <!-- Link 1 -->
                <p>
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>"><?php echo esc_html( "Link text $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_text ); ?>" />
            
                    <label for="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>"><?php echo esc_html( "Link url $i" ); ?></label>
                    <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_url ); ?>" />
                </p>
            
            <?php } ?>           
        <?php                
        }
    }
    register_widget( 'starter_footer_bottom_link_widget' );


    //**************************************************************************************
    // Custom User profile link Widget
    //**************************************************************************************

    class starter_user_profile_link_widget extends WP_Widget{    
        
        // Construct fn for id, title and description of the widget
        public function __construct()
        {
            $widget_details = array(
                'classname' => 'starter_user_profile_link_widget',
                'description' => esc_html__( 'User Profile Link Widget.','starter' )
            );
            parent::__construct( 'starter_user_profile_link_widget', esc_html__( '&#9733; User Profile Link Widget','starter' ) , $widget_details );
        }
      
        // Output of the widget
        public function widget( $args, $instance ) {
            
            $title = ! empty( $instance['title'] ) ? $instance['title']: '';             
           
            for( $i=1; $i<=$instance["inputbox"]; $i++ ) {
                    
                // Variable defind
                $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;  
                if( $link_text ): ?><a class="dropdown-item" href="<?php echo esc_url( $instance["link_url$i"] )  ?>"> <?php echo esc_html( $link_text ); ?> </a><?php endif;

            } 
        }    
        
        // Update user input data
        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }
        
        // Admin widget form
        public function form( $instance ) {

            $title = ! empty( $instance['title'] ) ? $instance['title']: ''; 
            $inputbox = ! empty( $instance["inputbox"] ) ? $instance["inputbox"] : '' ;

            ?>

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>"><b><?php esc_html_e( "Title","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "title" ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>"><b><?php esc_html_e( "How many social field would you want? & hit save.","starter" ); ?></b></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "inputbox" ) ); ?>" type="text" value="<?php echo esc_attr( $inputbox ); ?>" />
            </p>

            <?php
            
            for( $i=1; $i<=$inputbox; $i++ ) {

            // Variable defind
            $link_text = ! empty( $instance["link_text$i"] ) ? $instance["link_text$i"] : '' ;
            $link_url = ! empty( $instance["link_url$i"] ) ? $instance["link_url$i"] : '' ;     

            ?>  
            <!-- Link 1 -->
            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>"><?php echo esc_html( "Link text $i" ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_text$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_text ); ?>" />
           
                <label for="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>"><?php echo esc_html( "Link url $i" ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( "link_url$i" ) ); ?>" type="text" value="<?php echo esc_attr( $link_url ); ?>" />
            </p>
            
            <?php } ?>
           
        <?php                
        }
    }
    register_widget( 'starter_user_profile_link_widget' );


    //**************************************************************************************
    // Product category widget
    //**************************************************************************************

    class starter_mcat_widget extends WP_Widget{

        public function __construct()
        {
            $widget_details = array(
                'classname' => 'starter_mcat_widget',
                'description' => esc_html__( 'Starter Category Widget.', 'starter' )
            );
            parent::__construct( 'starter_mcat_widget', esc_html__( '&#9733; Product Category', 'starter' ), $widget_details );
        }
      
        public function widget( $args, $instance ){ 

            $title = $instance['title'];  
            global $post; 
            ?> 

            <div class="custom-category">
                <h2><?php echo esc_html( $title ); ?></h2>
                <ul>
                <?php
                $martcat = get_terms( 'download_category' );
                if( $martcat ):
                    foreach( $martcat as $cat_single ):
                        echo '<li><a href="'. esc_url( get_category_link( $cat_single->term_id ) ) .'"><span class="lnr lnr-chevron-right"></span>'." $cat_single->name ".'<span class="item-count">'." $cat_single->count ".' </span></a></li>';
                    endforeach;
                else:
                    echo "<li>" . esc_html__('There has no category.','starter') . "</li>";
                endif; ?>
                </ul>
            </div>

        <?php
        }

        public function update( $new_instance, $old_instance ) {  
            return $new_instance;
        }

        public function form( $instance ){        
            
            $title = esc_html__( 'Title','starter' );
            if(isset($instance['title']))
            {
                $title = $instance['title'];
            }         

            ?>       

            <p>
                <label for="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"><?php esc_html_e( 'Title','starter' ); ?></label>
                <input class="widefat" id="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
            </p>
            
        <?php
        }
    }
    register_widget( 'starter_mcat_widget' );

}
add_action( 'widgets_init', 'starter_register_widgets_init' );