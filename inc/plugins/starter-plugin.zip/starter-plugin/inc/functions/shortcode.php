<?php

/**
 * Related blog Shortcode
 * [blog-related-post title="Related Items" max_post="3" max_char="35"]
 */

function starter_blog_related_p0st_shortcode($atts){ 

	global $post;

	$terms = get_the_terms( $post->ID , 'category' );
	
	$cat_name = '';
	// Loop over each item since it's an array
	if ( $terms != null ){
		foreach( $terms as $term ) {
			// Print the name method from $term which is an OBJECT
			$cat_name = $term->name ;
			// Get rid of the other data stored in the object, since it's not needed
			unset($term);
		} 
	}

	if( $cat_name ) {

		// Params extraction
		extract(
			shortcode_atts(
				array(
					'title'        => '',
					'max_char'     => '35',
					'max_post'     => 6,
					'author'       => '',
					'product_para' => '',
					'category'     => '',
					'sale'         => '',
				),
				$atts
			)
		); 
		
		$args = array(
			'post_type'      => 'post',
			'post__not_in'   => get_option( 'sticky_posts' ),
			'posts_per_page' => $max_post,
			'orderby'        => 'rand',
		);

		$wp_query = new wp_query( $args );

		ob_start();	// Output buffering
		
		?>	

		<div class="related-articles">			
			<div class="row">

				<?php if( $title ): ?>
					<div class="col-md-12">
						<div class="title-left">
							<h2><?php echo esc_html( $title ); ?></h2>
						</div>                    
					</div>
				<?php endif; ?>

				<div class="col-md-12">
					<div class="row">  

						<?php 
			
						if( $wp_query->have_posts() ):
							while ( $wp_query->have_posts() ) : 
								$wp_query -> the_post(); 
								
								/**
								 * Read time count
								 */
								$post_object = get_post( $post->ID );
								$content = $post_object->post_content;
								$word_count = starter_count_content_words( $content );
								$time = ceil( $word_count / 200 );

								?>
								
								<div class="col-lg-4">
									<div class="row single-blog">
										
										<?php if( has_post_thumbnail() ): ?>
										<div class="col-md-8">
											<div class="blog-content">													

												<a href="<?php the_permalink();?>" title="<?php the_title();?>"><?php the_title(); ?></a>

												<div class="pub-meta">
													<span class="pub-author">
														<i class="las la-clock"></i> <?php echo esc_html( $time ) .esc_html__( ' min read', 'starter' ); ?>
													</span>
													<span class="pub-date">
														<i class="las la-pen"></i> <?php the_time('d M, Y');?>
													</span>
												</div>

											</div>
										</div>
										<div class="col-md-4">
											<div class="blog-thumbnail">
												<a href="<?php the_permalink();?>">
													<?php the_post_thumbnail();?>
												</a>
											</div>
										</div>

										<?php else: ?>

										<div class="col-md-12">
											<div class="blog-content">													

												<a href="<?php the_permalink();?>" title="<?php the_title();?>"><?php the_title(); ?></a>

												<div class="pub-meta">
													<span class="pub-author">
														<i class="las la-clock"></i> <?php echo esc_html( $time ) .esc_html__( ' min read', 'starter' ); ?>
													</span>
													<span class="pub-date">
														<i class="las la-pen"></i> <?php the_time('d M, Y');?>
													</span>
												</div>

											</div>
										</div>
										<?php endif; ?>

									</div>
								</div>									  

								<?php 									
							endwhile; 
							wp_reset_postdata();
						else:
					
						?>                
						
						<h3><?php echo esc_attr__( 'No related post.','starter' ); ?></h3>
						
						<?php endif; ?>   

					</div>
				</div>
			</div>			
		</div>

		<?php 
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;

}
add_shortcode('blog-related-post', 'starter_blog_related_p0st_shortcode');

/**
 * Contact page shortcode
 */
function starter_page_contact_shortcode( $atts, $content = null ) {	
	
	// Params extraction
	extract(
		shortcode_atts(
			array(
				'title'        => '',
				'desc'         => '',
				'form_title'   => '',
				'contact_form' => '',
			),
			$atts
		)
	);      

	ob_start();	// Output buffering	
	
	?>

	<div class="contact-section pt-190 pb-190">
		<div class="container">
			<div class="row">
				<div class="col-md-6">
					<div class="c-left-area">
						<div class="title-contact">							
							<?php if( $title ): ?><h2><?php echo esc_html( $title ); ?></h2><?php endif; ?>
							<?php if( $desc ): ?><p><?php echo wp_kses_post( $desc ); ?></p><?php endif; ?>
						</div>

						<?php 

						if( is_array( $atts['contact_adress'] ) ){
						foreach( $atts['contact_adress'] as $i => $item ): 

						$img = wp_get_attachment_image_src( $item->image_url,'full' );

						?>
						<div class="c-discript">
							<div class="c-icon">
								<img src="<?php echo esc_url( $img[0] ); ?>" alt="<?php echo esc_attr( $item->title ); ?>">
							</div>
							<div class="c-d-area">
								<h4><?php echo esc_html( $item->title ); ?></h4>
								<p><?php echo wp_kses_post( $item->adress ); ?></p>
							</div>
						</div>
						
						<?php endforeach; } ?>

					</div>
				</div>

				<div class="col-md-6">
					<div class="contact-form">
						<?php if( $form_title ): ?><h2><?php echo esc_html( $form_title ); ?></h2><?php endif; ?>
						<div id="contact">
							<?php echo do_shortcode( wp_kses_post( $contact_form ) ); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div><!-- End contact -->



	<?php 
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}
add_shortcode( 'starter_page_contact', 'starter_page_contact_shortcode' );
