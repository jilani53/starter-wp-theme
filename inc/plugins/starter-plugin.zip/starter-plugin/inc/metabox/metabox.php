<?php
/**
 * Metabox
 *
 * @package starter
 */

// ********************************************************************************************************************
// Blog Layout
// ********************************************************************************************************************

add_action( 'add_meta_boxes', 'starter_add_blog_meta_box' );
 
if ( ! function_exists( 'starter_add_blog_meta_box' ) ) {
    /**
     * Add meta box to page screen
     *
     * This function handles the addition of variuos meta boxes to your page or post screens.
     * You can add as many meta boxes as you want, but as a rule of thumb it's better to add
     * only what you need. If you can logically fit everything in a single metabox then add
     * it in a single meta box, rather than putting each control in a separate meta box.
     *
     * @since 1.0.0
     */
    function starter_add_blog_meta_box() {
        add_meta_box( 
            'additional-post-metabox-options', 
            esc_html__( 'Settings', 'starter' ), 
            'starter_metabox_blog_controls', 
            'post', 
            'normal', 
            'high' 
        );
    }
}

// Adding the control
if ( ! function_exists( 'starter_metabox_blog_controls' ) ) {
    /**
     * Meta box render function
     *
     * @param  object $post Post object.
     * @since  1.0.0
     */
    function starter_metabox_blog_controls( $post ) {

        $meta = get_post_meta( $post->ID );
              
        $select_layout = ( isset( $meta['select_layout'][0] ) && '' !== $meta['select_layout'][0] ) ? $meta['select_layout'][0] : '';        
        
        
        wp_nonce_field( 'starter_control_blog_meta_box', 'starter_control_blog_meta_box_nonce' ); // Always add nonce to your meta boxes!

        ?>
        
        <!--*********************************************************Product layout******************************-->
        <h3><?php _e( 'Select Post\'s Layout', 'starter' ); ?></h3>
        <hr/>

        <div class="post_meta_extras">        
            <p>
                <label>                    
                    <input type="radio" name="select_layout" value="1" <?php checked( $select_layout, '1' ); ?> checked>
                    <?php esc_html_e( 'Without Sidebar', 'starter' ); ?>
                </label>
                <label>                    
                    <input type="radio" name="select_layout" value="2" <?php checked( $select_layout, '2' ); ?>>
                    <?php esc_html_e( 'With Sidebar', 'starter' ); ?>
                </label>
            </p>
        </div>        

        <?php
    }
}

// Saving meta box
add_action( 'save_post', 'starter_save_post_metaboxes' );
 
if ( ! function_exists( 'starter_save_post_metaboxes' ) ) {
    /**
     * Save controls from the meta boxes
     *
     * @param  int $post_id Current post id.
     * @since 1.0.0
     */
    function starter_save_post_metaboxes( $post_id ) {
        /*
         * We need to verify this came from the our screen and with proper authorization,
         * because save_post can be triggered at other times. Add as many nonces, as you
         * have metaboxes.
         */
        if ( ! isset( $_POST['starter_control_blog_meta_box_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['starter_control_blog_meta_box_nonce'] ), 'starter_control_blog_meta_box' ) ) { // Input var okay.
            return $post_id;
        }
 
        // Check the user's permissions.
        if ( isset( $_POST['post_type'] ) && 'page' === $_POST['post_type'] ) { // Input var okay.
            if ( ! current_user_can( 'edit_page', $post_id ) ) {
                return $post_id;
            }
        } else {
            if ( ! current_user_can( 'edit_post', $post_id ) ) {
                return $post_id;
            }
        }
 
        /*
         * If this is an autosave, our form has not been submitted,
         * so we don't want to do anything.
         */
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return $post_id;
        }
 
        /* Ok to save */ 
 
        if ( isset( $_POST['select_layout'] )) { // Input var okay.
            update_post_meta( $post_id, 'select_layout', sanitize_text_field( wp_unslash( $_POST['select_layout'] ) ) ); // Input var okay.
        }
        
    }
}
