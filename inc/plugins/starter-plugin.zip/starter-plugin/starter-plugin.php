<?php
/*
Plugin Name: Starter Plugin
Plugin URI: https://wpninjadevs.com/
Description: This plugin is developed to build Starter theme features.
Author: wpninjaDevs
Version: 1.6
Author URI: https://wpninjadevs.com/
*/

add_filter( 'widget_text', 'do_shortcode' );

/**
 * Load plugin textdomain.
 */
function starter_load_textdomain() {
    load_plugin_textdomain( 'starter_textdomain', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' ); 
}
add_action( 'init', 'starter_load_textdomain' );

require_once 'inc/metabox/metabox.php';
// require_once 'inc/like/post-like.php';

// Inner pages
require_once 'inc/functions/shortcode.php';
require_once 'inc/functions/custom-widget.php';

/**
 * Starter Elementor initialization
 * 
 * @return void
 */
//require_once 'inc/elementor-widget/initialization.php';
